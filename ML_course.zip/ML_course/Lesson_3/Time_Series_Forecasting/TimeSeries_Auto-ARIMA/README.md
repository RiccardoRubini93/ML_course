# TimeSeries_Auto-ARIMA
This project is created to demonstrate how Auto ARIMA works in Python with "pmdarima" package for Time Series Analysis
